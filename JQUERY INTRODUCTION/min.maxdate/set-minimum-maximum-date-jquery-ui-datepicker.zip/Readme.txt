Author: Yogesh singh
Author URL: http://makitweb.com/
Author Email: yssyogesh@makitweb.com
Tutorial Link: http://makitweb.com/set-minimum-maximum-date-in-jquery-ui-datepicker/
